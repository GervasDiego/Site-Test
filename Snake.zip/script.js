const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const startButton = document.getElementById("startButton");
const gameOverDiv = document.getElementById("gameOver");
const restartButton = document.getElementById("restartButton");

const box = 20;
let snake, direction, food, game;

function initGame() {
  snake = [{ x: 9 * box, y: 10 * box }];
  direction = "RIGHT";
  food = {
    x: Math.floor(Math.random() * 19 + 1) * box,
    y: Math.floor(Math.random() * 19 + 1) * box
  };
}

document.addEventListener("keydown", changeDirection);
startButton.addEventListener("click", () => {
  startButton.style.display = "none";
  canvas.style.display = "block";
  initGame();
  game = setInterval(draw, 100);
});
restartButton.addEventListener("click", () => {
  gameOverDiv.style.display = "none";
  canvas.style.display = "block";
  initGame();
  game = setInterval(draw, 100);
});

function changeDirection(event) {
  if (event.key === "ArrowLeft" && direction !== "RIGHT") direction = "LEFT";
  else if (event.key === "ArrowUp" && direction !== "DOWN") direction = "UP";
  else if (event.key === "ArrowRight" && direction !== "LEFT") direction = "RIGHT";
  else if (event.key === "ArrowDown" && direction !== "UP") direction = "DOWN";
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  for (let i = 0; i < snake.length; i++) {
    ctx.fillStyle = i === 0 ? "lime" : "green";
    ctx.fillRect(snake[i].x, snake[i].y, box, box);
  }

  ctx.fillStyle = "red";
  ctx.fillRect(food.x, food.y, box, box);

  let head = { x: snake[0].x, y: snake[0].y };

  if (direction === "LEFT") head.x -= box;
  if (direction === "UP") head.y -= box;
  if (direction === "RIGHT") head.x += box;
  if (direction === "DOWN") head.y += box;

  if (head.x === food.x && head.y === food.y) {
    food = {
      x: Math.floor(Math.random() * 19 + 1) * box,
      y: Math.floor(Math.random() * 19 + 1) * box
    };
  } else {
    snake.pop();
  }

  snake.unshift(head);

  if (
    head.x < 0 || head.x >= canvas.width ||
    head.y < 0 || head.y >= canvas.height ||
    snake.slice(1).some(segment => segment.x === head.x && segment.y === head.y)
  ) {
    clearInterval(game);
    gameOverDiv.style.display = "block";
  }
}

function setScenario(scenario) {
  document.body.classList.remove('standard', 'fire', 'water', 'grass');
  document.body.classList.add('standard'); 

  document.body.classList.add(scenario);
}

window.onload = function() {
  setScenario('standard');
};
